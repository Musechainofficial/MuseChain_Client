export interface MessageDto {
  success: string
}
