export interface nftDto {
  art_name: string
  artist: string
  image: string
  rare: string
  price: number
  url: string
}