import "./App.css"
import "./assets/css/generated.css"
import "./assets/css/style.css"
import Routers from "./components/Router";


const App = () => {
  return (
    <Routers />
  );
}

export default App;